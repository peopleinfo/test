module.exports = {
  apps: [
    {
      name: 'snake-zone-server',
      script: './server/server.js',
      instances: 1, // Single instance for Socket.io sticky sessions
      exec_mode: 'fork', // Fork mode for Socket.io compatibility
      watch: false, // Disable watch in production
      max_memory_restart: '200M',
      env: {
        NODE_ENV: 'production',
        PORT: 9000
      },
      env_development: {
        NODE_ENV: 'development',
        PORT: 9000,
        watch: true,
        ignore_watch: ['node_modules', 'logs']
      },
      env_staging: {
        NODE_ENV: 'staging',
        PORT: 9000
      },
      // Logging configuration
      log_file: './logs/combined.log',
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      
      // Process management
      min_uptime: '10s',
      max_restarts: 10,
      restart_delay: 4000,
      
      // Advanced PM2 features
      kill_timeout: 5000,
      listen_timeout: 3000,
      
      // Health monitoring
      health_check_grace_period: 3000,
      
      // Socket.io specific settings
      node_args: '--max-old-space-size=256',
      
      // Graceful shutdown
      shutdown_with_message: true,
      wait_ready: true,
      
      // Cron restart (optional - restart daily at 3 AM)
      cron_restart: '0 3 * * *',
      
      // Merge logs from all instances
      merge_logs: true,
      
      // Auto restart on file changes (development only)
      autorestart: true,
      
      // Source map support
      source_map_support: false
    }
  ],
  
  // Deployment configuration
  deploy: {
    production: {
      user: 'deploy',
      host: ['your-server.com'],
      ref: 'origin/main',
      repo: 'git@github.com:your-username/snake-zone.git',
      path: '/var/www/snake-zone',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env production',
      'pre-setup': 'apt update && apt install git -y'
    },
    staging: {
      user: 'deploy',
      host: ['staging-server.com'],
      ref: 'origin/develop',
      repo: 'git@github.com:your-username/snake-zone.git',
      path: '/var/www/snake-zone-staging',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env staging'
    }
  }
};