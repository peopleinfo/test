export interface ScoreAnimationData {
  id: string;
  x: number;
  y: number;
  points: number;
  startTime: number;
  duration: number;
  opacity: number;
  offsetY: number;
  scale: number;
  glowIntensity: number;
}

export class ScoreAnimation {
  private animations: ScoreAnimationData[] = [];
  private readonly FADE_START = 0.5; // Start fading at 50% of animation - Enhanced per PRD
  
  private readonly POINT_THRESHOLDS = {
    15: 15,
    12: 12,
    9: 9,
    6: 6,
    3: 3
  } as const;

  // Animation configurations for different point values
  private readonly ANIMATION_CONFIGS = {
    normal: { duration: 1000, floatDistance: 18, fontSize: 4, glowIntensity: 0 },
    dead20: { duration: 1050, floatDistance: 19, fontSize: 4.1, glowIntensity: 0.2 },
    dead30: { duration: 1100, floatDistance: 20, fontSize: 4.15, glowIntensity: 0.3 },
    dead40: { duration: 1150, floatDistance: 21, fontSize: 4.2, glowIntensity: 0.4 },
    dead100: { duration: 1200, floatDistance: 22, fontSize: 4.25, glowIntensity: 0.5 }
  }
  // Add a new score animation
  addAnimation(x: number, y: number, points: number): void {
    const config = this.getAnimationConfig(points);
    const animation: ScoreAnimationData = {
      id: `score_${Date.now()}_${Math.random()}`,
      x,
      y,
      points,
      startTime: Date.now(),
      duration: config.duration,
      opacity: 1,
      offsetY: 0,
      scale: 1,
      glowIntensity: config.glowIntensity
    };
    
    this.animations.push(animation);
    
    // Limit the number of active animations for performance
    if (this.animations.length > 15) {
      this.animations.shift();
    }
  }
  
  // Get animation configuration based on points
  private getAnimationConfig(points: number) {
    if (points >= this.POINT_THRESHOLDS[15]) return this.ANIMATION_CONFIGS.dead100;
    if (points >= this.POINT_THRESHOLDS[12]) return this.ANIMATION_CONFIGS.dead40;
    if (points >= this.POINT_THRESHOLDS[8]) return this.ANIMATION_CONFIGS.dead30;
    if (points >= this.POINT_THRESHOLDS[5]) return this.ANIMATION_CONFIGS.dead20;
    return this.ANIMATION_CONFIGS.normal;
  }

  // Update all active animations
  update(): void {
    const now = Date.now();
    
    // Update each animation
    for (let i = this.animations.length - 1; i >= 0; i--) {
      const animation = this.animations[i];
      const elapsed = now - animation.startTime;
      const progress = Math.min(elapsed / animation.duration, 1);
      const config = this.getAnimationConfig(animation.points); 
      
      // Enhanced cubic-bezier easing function (0.25, 0.46, 0.45, 0.94) per PRD
      const t = progress;
      const cubicBezier = 3 * (1 - t) * (1 - t) * t * 0.25 + 3 * (1 - t) * t * t * 0.46 + t * t * t * 0.94;
      animation.offsetY = -config.floatDistance * cubicBezier;
      
      // Enhanced smoother opacity transition starting at 50% per PRD
      if (progress >= this.FADE_START) {
        const fadeProgress = (progress - this.FADE_START) / (1 - this.FADE_START);
        // Smoother fade-out with cubic easing
        animation.opacity = 1 - (fadeProgress * fadeProgress * (3 - 2 * fadeProgress));
      }
      
      // Remove completed animations
      if (progress >= 1) {
        this.animations.splice(i, 1);
      }
    }
  }

  // Render all active animations
  render(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    
    for (const animation of this.animations) {
      const config = this.getAnimationConfig(animation.points);
      
      ctx.save();
      ctx.globalAlpha = animation.opacity;
      
      // Apply scaling transformation
      ctx.translate(animation.x, animation.y + animation.offsetY);
      ctx.scale(animation.scale, animation.scale);
      
      // Enhanced text properties with better visibility
      ctx.font = `bold ${config.fontSize}px Baloo-Regular`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Add glow effect for higher point values
      if (animation.glowIntensity > 0) {
        ctx.shadowColor = this.getGlowColor(animation.points);
        ctx.shadowBlur = 4 * animation.glowIntensity;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;
      }
      
      // Enhanced text shadow with increased width for better visibility per PRD
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.lineWidth = config.fontSize * 0.3;
      ctx.strokeText(`+${animation.points}`, 0, 0);
      
      // Set fill color based on point value
      ctx.fillStyle = this.getPointColor(animation.points);
      ctx.fillText(`+${animation.points}`, 0, 0);
      
      ctx.restore();
    }
    
    ctx.restore();
  }
  
  // Get color based on point value
  private getPointColor(points: number): string {
    if (points >= this.POINT_THRESHOLDS[15]) return '#FF0080'; // Hot pink for 100+
    if (points >= this.POINT_THRESHOLDS[12]) return '#8A2BE2'; // Blue violet for 40+
    if (points >= this.POINT_THRESHOLDS[8]) return '#FF4500'; // Orange red for 30+ 
    if (points >= this.POINT_THRESHOLDS[5]) return '#32CD32'; // Lime green for 20+
    if (points === this.POINT_THRESHOLDS[3]) return '#FFD60A'; // Bright yellow for 1 point
    return '#FF9F0A'; // Gold for 2+ points
  }
  
  // Get glow color based on point value
  private getGlowColor(points: number): string {
    if (points >= this.POINT_THRESHOLDS[15]) return '#FF0080';
    if (points >= this.POINT_THRESHOLDS[12]) return '#8A2BE2';
    if (points >= this.POINT_THRESHOLDS[8]) return '#FF4500';
    if (points >= this.POINT_THRESHOLDS[5]) return '#32CD32';
    if (points === this.POINT_THRESHOLDS[3]) return '#FFD60A';
    return '#FF9F0A';
  }

  // Clear all animations
  clear(): void {
    this.animations = [];
  }

  // Get the number of active animations
  getActiveCount(): number {
    return this.animations.length;
  }
}