import { POINT } from "../config/gameConfig";
import { getRandomColor, getRandX, getRandY, lerp } from "../utils/gameUtils";
import { Point } from "./Point";
import { useSettingsStore } from "../stores/settingsStore";
import {
  shouldDrawShadow,
  getShadowConfig,
  getQualityConfig,
} from "../utils/qualityUtils";

type Type = "watermelon" | "apple" | "cherry" | "orange" | "grapes";

const IMG_RADIUS = 3;
const APPPLE_RADIUS = 2.8;
const ORANNG_RADIUS = 3.1;
const CHERRY_RADIUS = 3.1;
const GRAPES_RADIUS = 3.1;

// FIXED: Use integer value for crisp rendering
const FOOD_RADIUS = 5;

export class Food extends Point {
  static i: number = 0;
  static imageCache: Map<string, HTMLCanvasElement> = new Map();
  id: string;
  type: Type;
  private imageReady: boolean = false;

  constructor(
    id: string,
    x: number,
    y: number,
    radius: number,
    color: string,
    type?: Type
  ) {
    super(x, y, radius, color);
    this.id = id;
    this.type = type || this.getRandomFood();
    this.createFoodImage();
  }

  private getRandomFood(): Type {
    const types: Type[] = ["watermelon", "apple", "cherry", "orange", "grapes"];
    return types[Math.floor(Math.random() * types.length)];
  }

  // Get point value based on food type (sync with server-side logic - updated to new point system)
  getPointValue(): number {
    switch (this.type) {
      case "watermelon":
        return 3;
      case "apple":
        return 6;
      case "cherry":
        return 9;
      case "orange":
        return 12;
      case "grapes":
        return 50;
      default:
        return POINT; // fallback
    }
  }

  private createFoodImage(): void {
    const cacheKey = `${this.type}_${this.radius}`;

    if (Food.imageCache.has(cacheKey)) {
      this.imageReady = true;
      return;
    }

    const canvas = document.createElement("canvas");

    // FIXED: Use devicePixelRatio for crisp rendering
    const pixelRatio = window.devicePixelRatio || 1;
    const canvasSize = this.radius * FOOD_RADIUS * 2 * pixelRatio;

    canvas.width = canvasSize;
    canvas.height = canvasSize;
    canvas.style.width = Math.round(this.radius * FOOD_RADIUS * 2) + "px";
    canvas.style.height = Math.round(this.radius * FOOD_RADIUS * 2) + "px";

    const ctx = canvas.getContext("2d");

    if (!ctx) {
      this.imageReady = false;
      return;
    }

    // FIXED: Scale context to match devicePixelRatio like GameEngine does
    ctx.scale(pixelRatio, pixelRatio);

    // FIXED: Use same high-quality settings as Snake rendering
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.lineJoin = "round";
    ctx.lineCap = "round";

    // FIXED: Remove conflicting settings and use clean approach
    ctx.globalAlpha = 1.0;
    ctx.globalCompositeOperation = "source-over";

    // FIXED: Use direct coordinates - canvas context already handles devicePixelRatio scaling
    const centerX = this.radius * FOOD_RADIUS;
    const centerY = this.radius * FOOD_RADIUS;
    const drawRadius = this.radius;

    // Draw different food types
    switch (this.type) {
      case "apple":
        this.drawApple(ctx, centerX, centerY, drawRadius);
        break;
      case "watermelon":
        this.drawWatermelon(ctx, centerX, centerY, drawRadius);
        break;
      case "cherry":
        this.drawCherry(ctx, centerX, centerY, drawRadius);
        break;
      case "orange":
        this.drawOrange(ctx, centerX, centerY, drawRadius);
        break;
      case "grapes":
        this.drawGrapes(ctx, centerX, centerY, drawRadius);
        break;
    }

    // FIXED: Use consistent canvas optimization like GameEngine
    canvas.style.imageRendering = "auto";
    canvas.style.willChange = "transform";
    canvas.style.transform = "translateZ(0)";

    Food.imageCache.set(cacheKey, canvas);
    this.imageReady = true;
  }

  private drawFoodImage(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number,
    imagePath: string,
    scaleFactor: number = IMG_RADIUS // Default to IMG_RADIUS but can be customized
  ): void {
    const img = new Image();
    img.crossOrigin = "anonymous";

    img.onload = () => {
      // Calculate the target size for the food
      const targetSize = radius * scaleFactor;
      
      // Get original image dimensions
      const imgWidth = img.naturalWidth || img.width;
      const imgHeight = img.naturalHeight || img.height;
      
      // Calculate aspect ratios
      const imgAspectRatio = imgWidth / imgHeight;
      const targetAspectRatio = 1; // We want a square target area
      
      // Calculate scaling to implement object-fit: contain behavior
      let drawWidth: number;
      let drawHeight: number;
      
      if (imgAspectRatio > targetAspectRatio) {
        // Image is wider than target - fit by width, leave vertical space
        drawWidth = targetSize;
        drawHeight = targetSize / imgAspectRatio;
      } else {
        // Image is taller than target - fit by height, leave horizontal space
        drawWidth = targetSize * imgAspectRatio;
        drawHeight = targetSize;
      }
      
      // Calculate final draw position (centered with potential empty space)
      const drawX = x - drawWidth / 2;
      const drawY = y - drawHeight / 2;

      // Enable high-quality smoothing for ultra-HD
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";

      // Draw entire image scaled to fit within target area (object-fit: contain)
      ctx.drawImage(
        img,
        0, 0, imgWidth, imgHeight, // Source rectangle (entire image)
        drawX, drawY, drawWidth, drawHeight // Destination rectangle (scaled to fit)
      );

      // Update the cache with the new image
      const cacheKey = `${this.type}_${this.radius}`;
      const canvas = ctx.canvas;
      Food.imageCache.set(cacheKey, canvas);
      this.imageReady = true;
    };

    img.onerror = () => {
      // Fallback to a simple circle if image fails to load
      ctx.fillStyle = "#FFD700";
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
      this.imageReady = true;
    };

    img.src = imagePath;
  }
  private drawOrange(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    this.drawFoodImage(ctx, x, y, radius, "/icons/orange.png", ORANNG_RADIUS);
  }
  private drawGrapes(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    this.drawFoodImage(ctx, x, y, radius, "/icons/grapes.png", GRAPES_RADIUS);
  }
  private drawApple(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    this.drawFoodImage(ctx, x, y, radius, "/icons/apple.png", APPPLE_RADIUS);
  }
  private drawWatermelon(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    this.drawFoodImage(ctx, x, y, radius, "/icons/watermelon.png");
  }
  private drawCherry(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    this.drawFoodImage(ctx, x, y, radius, "/icons/cherry.png", CHERRY_RADIUS);
  }

  public drawAppleCanvas(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    // FIXED: Use direct coordinates - canvas context already handles devicePixelRatio scaling
    const centerX = x;
    const centerY = y;
    const drawRadius = radius;

    // Add shadow for depth
    ctx.shadowColor = "rgba(0, 0, 0, 0.3)";
    ctx.shadowBlur = 4;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;

    // Apple body with gradient
    const appleGradient = ctx.createRadialGradient(
      centerX - drawRadius * 0.3,
      centerY - drawRadius * 0.2,
      0,
      centerX,
      centerY + drawRadius * 0.1,
      drawRadius * 0.9
    );
    appleGradient.addColorStop(0, "#FF6B6B");
    appleGradient.addColorStop(0.4, "#FF4444");
    appleGradient.addColorStop(0.8, "#DC143C");
    appleGradient.addColorStop(1, "#8B0000");

    ctx.fillStyle = appleGradient;
    ctx.beginPath();
    ctx.arc(
      centerX,
      centerY + drawRadius * 0.1,
      drawRadius * 0.9,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Reset shadow for highlight
    ctx.shadowColor = "transparent";

    // Apple highlight with gradient
    const highlightGradient = ctx.createRadialGradient(
      centerX - drawRadius * 0.4,
      centerY - drawRadius * 0.2,
      0,
      centerX - drawRadius * 0.3,
      centerY - drawRadius * 0.1,
      drawRadius * 0.3
    );
    highlightGradient.addColorStop(0, "rgba(255, 255, 255, 0.8)");
    highlightGradient.addColorStop(0.5, "rgba(255, 136, 136, 0.6)");
    highlightGradient.addColorStop(1, "rgba(255, 68, 68, 0.2)");

    ctx.fillStyle = highlightGradient;
    ctx.beginPath();
    ctx.arc(
      centerX - drawRadius * 0.3,
      centerY - drawRadius * 0.1,
      drawRadius * 0.3,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Apple stem with gradient
    const stemGradient = ctx.createLinearGradient(
      centerX - 2,
      centerY - drawRadius,
      centerX + 2,
      centerY - drawRadius * 0.7
    );
    stemGradient.addColorStop(0, "#A0522D");
    stemGradient.addColorStop(1, "#8B4513");

    ctx.fillStyle = stemGradient;
    ctx.fillRect(centerX - 2, centerY - drawRadius, 4, drawRadius * 0.3);

    // Apple leaf with gradient
    const leafGradient = ctx.createLinearGradient(
      centerX + drawRadius * 0.1,
      centerY - drawRadius * 0.8,
      centerX + drawRadius * 0.3,
      centerY - drawRadius * 0.6
    );
    leafGradient.addColorStop(0, "#32CD32");
    leafGradient.addColorStop(0.5, "#228B22");
    leafGradient.addColorStop(1, "#006400");

    ctx.fillStyle = leafGradient;
    ctx.beginPath();
    ctx.ellipse(
      centerX + drawRadius * 0.2,
      centerY - drawRadius * 0.7,
      drawRadius * 0.2,
      drawRadius * 0.1,
      Math.PI / 4,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }
  public drawCherryCanvas(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    // FIXED: Use direct coordinates - canvas context already handles devicePixelRatio scaling
    const centerX = x;
    const centerY = y;
    const drawRadius = radius;

    // Add shadow for depth
    ctx.shadowColor = "rgba(0, 0, 0, 0.3)";
    ctx.shadowBlur = 3;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;

    // Cherry 1 with gradient
    const cherry1Gradient = ctx.createRadialGradient(
      centerX - drawRadius * 0.4,
      centerY + drawRadius * 0.1,
      0,
      centerX - drawRadius * 0.3,
      centerY + drawRadius * 0.2,
      drawRadius * 0.6
    );
    cherry1Gradient.addColorStop(0, "#FF6B6B");
    cherry1Gradient.addColorStop(0.3, "#FF4444");
    cherry1Gradient.addColorStop(0.7, "#DC143C");
    cherry1Gradient.addColorStop(1, "#8B0000");

    ctx.fillStyle = cherry1Gradient;
    ctx.beginPath();
    ctx.arc(
      centerX - drawRadius * 0.3,
      centerY + drawRadius * 0.2,
      drawRadius * 0.6,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Cherry 2 with gradient
    const cherry2Gradient = ctx.createRadialGradient(
      centerX + drawRadius * 0.2,
      centerY + drawRadius * 0.1,
      0,
      centerX + drawRadius * 0.3,
      centerY + drawRadius * 0.2,
      drawRadius * 0.6
    );
    cherry2Gradient.addColorStop(0, "#FF6B6B");
    cherry2Gradient.addColorStop(0.3, "#FF4444");
    cherry2Gradient.addColorStop(0.7, "#DC143C");
    cherry2Gradient.addColorStop(1, "#8B0000");

    ctx.fillStyle = cherry2Gradient;
    ctx.beginPath();
    ctx.arc(
      centerX + drawRadius * 0.3,
      centerY + drawRadius * 0.2,
      drawRadius * 0.6,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Add highlights to cherries
    ctx.shadowColor = "transparent";

    // Cherry 1 highlight
    ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
    ctx.beginPath();
    ctx.arc(
      centerX - drawRadius * 0.4,
      centerY + drawRadius * 0.1,
      drawRadius * 0.2,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Cherry 2 highlight
    ctx.beginPath();
    ctx.arc(
      centerX + drawRadius * 0.2,
      centerY + drawRadius * 0.1,
      drawRadius * 0.2,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Stems with gradient
    const stemGradient = ctx.createLinearGradient(
      centerX,
      centerY - drawRadius * 0.8,
      centerX,
      centerY - drawRadius * 0.2
    );
    stemGradient.addColorStop(0, "#32CD32");
    stemGradient.addColorStop(0.5, "#228B22");
    stemGradient.addColorStop(1, "#006400");

    ctx.strokeStyle = stemGradient;
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(centerX - drawRadius * 0.3, centerY - drawRadius * 0.2);
    ctx.lineTo(centerX - drawRadius * 0.1, centerY - drawRadius * 0.8);
    ctx.moveTo(centerX + drawRadius * 0.3, centerY - drawRadius * 0.2);
    ctx.lineTo(centerX + drawRadius * 0.1, centerY - drawRadius * 0.8);
    ctx.stroke();
  }
  public drawOrangeCanvas(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number
  ): void {
    // FIXED: Use direct coordinates - canvas context already handles devicePixelRatio scaling
    const centerX = x;
    const centerY = y;
    const drawRadius = radius;

    // Enhanced black shadow for better visibility
    ctx.shadowColor = "rgba(0, 0, 0, 0.6)";
    ctx.shadowBlur = drawRadius * 0.4;
    ctx.shadowOffsetX = drawRadius * 0.2;
    ctx.shadowOffsetY = drawRadius * 0.2;

    // Orange body with emoji-style gradient
    const orangeGradient = ctx.createRadialGradient(
      centerX - drawRadius * 0.3,
      centerY - drawRadius * 0.2,
      0,
      centerX,
      centerY,
      drawRadius * 0.9
    );
    orangeGradient.addColorStop(0, "#FFB347"); // Light orange center
    orangeGradient.addColorStop(0.3, "#FF8C00"); // Dark orange
    orangeGradient.addColorStop(0.6, "#FF7F00"); // Orange red
    orangeGradient.addColorStop(0.8, "#FF6347"); // Tomato
    orangeGradient.addColorStop(1, "#CD5C5C"); // Indian red edge

    ctx.fillStyle = orangeGradient;
    ctx.beginPath();
    ctx.arc(centerX, centerY, drawRadius * 0.9, 0, Math.PI * 2);
    ctx.fill();

    // Reset shadow for highlights
    ctx.shadowColor = "transparent";

    // Orange texture (dimpled surface)
    const texturePoints: { x: number; y: number }[] = [];
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const distance = drawRadius * 0.6;
      texturePoints.push({
        x: Math.round(centerX + Math.cos(angle) * distance),
        y: Math.round(centerY + Math.sin(angle) * distance),
      });
    }

    ctx.fillStyle = "rgba(255, 140, 0, 0.3)";
    texturePoints.forEach((point) => {
      ctx.beginPath();
      ctx.arc(point.x, point.y, drawRadius * 0.05, 0, Math.PI * 2);
      ctx.fill();
    });

    // Orange glossy highlight
    const orangeHighlight = ctx.createRadialGradient(
      centerX - drawRadius * 0.35,
      centerY - drawRadius * 0.35,
      0,
      centerX - drawRadius * 0.2,
      centerY - drawRadius * 0.2,
      drawRadius * 0.4
    );
    orangeHighlight.addColorStop(0, "rgba(255, 255, 255, 0.9)");
    orangeHighlight.addColorStop(0.4, "rgba(255, 255, 255, 0.6)");
    orangeHighlight.addColorStop(0.7, "rgba(255, 200, 150, 0.4)");
    orangeHighlight.addColorStop(1, "rgba(255, 180, 100, 0.1)");

    ctx.fillStyle = orangeHighlight;
    ctx.beginPath();
    ctx.arc(
      centerX - drawRadius * 0.2,
      centerY - drawRadius * 0.2,
      drawRadius * 0.4,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Secondary highlight for extra shine
    const secondaryHighlight = ctx.createRadialGradient(
      centerX - drawRadius * 0.1,
      centerY - drawRadius * 0.45,
      0,
      centerX - drawRadius * 0.05,
      centerY - drawRadius * 0.4,
      drawRadius * 0.12
    );
    secondaryHighlight.addColorStop(0, "rgba(255, 255, 255, 0.8)");
    secondaryHighlight.addColorStop(0.6, "rgba(255, 220, 180, 0.4)");
    secondaryHighlight.addColorStop(1, "rgba(255, 200, 150, 0.1)");

    ctx.fillStyle = secondaryHighlight;
    ctx.beginPath();
    ctx.arc(
      centerX - drawRadius * 0.05,
      centerY - drawRadius * 0.4,
      drawRadius * 0.12,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Orange leaf (small green leaf on top)
    const leafGradient = ctx.createRadialGradient(
      centerX,
      centerY - drawRadius * 0.8,
      0,
      centerX + drawRadius * 0.1,
      centerY - drawRadius * 0.7,
      drawRadius * 0.2
    );
    leafGradient.addColorStop(0, "#7FFF00"); // Chartreuse
    leafGradient.addColorStop(0.5, "#32CD32"); // Lime green
    leafGradient.addColorStop(1, "#228B22"); // Forest green

    ctx.fillStyle = leafGradient;
    ctx.beginPath();
    ctx.ellipse(
      centerX + drawRadius * 0.05,
      centerY - drawRadius * 0.75,
      drawRadius * 0.15,
      drawRadius * 0.08,
      Math.PI / 6,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Reset shadow completely
    ctx.shadowColor = "transparent";
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
  }

  // Override isInViewport to include food-specific logic if needed
  isInViewport(
    viewX: number,
    viewY: number,
    viewWidth: number,
    viewHeight: number
  ): boolean {
    const margin = this.radius * 3; // Add some margin for smooth transitions
    return (
      this.x + margin >= viewX &&
      this.x - margin <= viewX + viewWidth &&
      this.y + margin >= viewY &&
      this.y - margin <= viewY + viewHeight
    );
  }

  regenerate(canvasWidth: number = 800, canvasHeight: number = 600): void {
    this.x = getRandX(canvasWidth);
    this.y = getRandY(canvasHeight);
    this.color = getRandomColor();
    // Generate new food type for variety
    this.type = this.getRandomFood();
    this.createFoodImage();
  }

  animate(): void {
    this.radius = lerp(this.radius * 0.8, this.radius, ++Food.i / this.radius);
    Food.i %= 17;
  }

  draw(ctx: CanvasRenderingContext2D): void {
    // Save current context state
    ctx.save();

    // Get current quality settings
    let quality: "low" | "medium" | "hd" = "hd";
    try {
      quality = useSettingsStore.getState().quality;
    } catch (error) {
      console.warn("Failed to get quality settings:", error);
    }

    const qualityConfig = getQualityConfig(quality);

    // Apply quality settings to context
    ctx.imageSmoothingEnabled = qualityConfig.imageSmoothing;
    ctx.imageSmoothingQuality = qualityConfig.imageSmoothing ? "high" : "low";

    // Use cached food image if available, otherwise fallback to circle
    if (this.imageReady) {
      const cacheKey = `${this.type}_${this.radius}`;
      const foodImage = Food.imageCache.get(cacheKey);

      if (foodImage) {
        const size = this.radius * FOOD_RADIUS;

        // FIXED: Use direct coordinates - canvas context already handles devicePixelRatio scaling
        const drawX = this.x - size / 2;
        const drawY = this.y - size / 2;
        const drawSize = size;

        // Apply high-quality image rendering
        ctx.drawImage(foodImage, drawX, drawY, drawSize, drawSize);

        // Restore context state
        ctx.restore();
        return;
      }
    }

    // Enhanced fallback rendering with gradients and anti-aliasing
    const drawColor = this.color;

    // Add shadow based on quality settings
    if (shouldDrawShadow(quality)) {
      const shadowConfig = getShadowConfig(quality);
      ctx.shadowColor = shadowConfig.shadowColor;
      ctx.shadowBlur = shadowConfig.shadowBlur;
      ctx.shadowOffsetX = shadowConfig.shadowOffsetX;
      ctx.shadowOffsetY = shadowConfig.shadowOffsetY;
    }

    // Create gradient for better visual appeal (only for medium and HD quality)
    if (qualityConfig.detailLevel >= 2) {
      const gradient = ctx.createRadialGradient(
        this.x - this.radius * 0.3,
        this.y - this.radius * 0.3,
        0,
        this.x,
        this.y,
        this.radius
      );

      // Parse color and create lighter/darker variants
      const baseColor = drawColor;
      const lighterColor = this.lightenColor(baseColor, 0.3);
      const darkerColor = this.darkenColor(baseColor, 0.2);

      gradient.addColorStop(0, lighterColor);
      gradient.addColorStop(0.7, baseColor);
      gradient.addColorStop(1, darkerColor);

      ctx.fillStyle = gradient;
    } else {
      // Simple solid color for low o
      ctx.fillStyle = drawColor;
    }

    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fill();

    // Reset shadow for border
    ctx.shadowColor = "transparent";

    // Enhanced border with gradient (only for HD quality)
    if (qualityConfig.detailLevel >= 3) {
      const borderGradient = ctx.createLinearGradient(
        this.x - this.radius,
        this.y - this.radius,
        this.x + this.radius,
        this.y + this.radius
      );
      borderGradient.addColorStop(0, "rgba(255, 255, 255, 0.8)");
      borderGradient.addColorStop(1, "rgba(255, 255, 255, 0.3)");

      ctx.strokeStyle = borderGradient;
      ctx.lineWidth = 2;
      ctx.lineCap = "round";
      ctx.stroke();
    }

    // Restore context state
    ctx.restore();
  }

  private lightenColor(color: string, factor: number): string {
    // Simple color lightening - works with hex colors
    if (color.startsWith("#")) {
      const hex = color.slice(1);
      const num = parseInt(hex, 16);
      const r = Math.min(
        255,
        Math.floor((num >> 16) + (255 - (num >> 16)) * factor)
      );
      const g = Math.min(
        255,
        Math.floor(
          ((num >> 8) & 0x00ff) + (255 - ((num >> 8) & 0x00ff)) * factor
        )
      );
      const b = Math.min(
        255,
        Math.floor((num & 0x0000ff) + (255 - (num & 0x0000ff)) * factor)
      );
      return `rgb(${r}, ${g}, ${b})`;
    }
    return color;
  }

  private darkenColor(color: string, factor: number): string {
    // Simple color darkening - works with hex colors
    if (color.startsWith("#")) {
      const hex = color.slice(1);
      const num = parseInt(hex, 16);
      const r = Math.floor((num >> 16) * (1 - factor));
      const g = Math.floor(((num >> 8) & 0x00ff) * (1 - factor));
      const b = Math.floor((num & 0x0000ff) * (1 - factor));
      return `rgb(${r}, ${g}, ${b})`;
    }
    return color;
  }
}
