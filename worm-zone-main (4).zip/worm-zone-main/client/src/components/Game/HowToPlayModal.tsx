import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { X } from "lucide-react";

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { t } = useTranslation(["common", "game"]);
  const [isClosing, setIsClosing] = useState(false);

  // Handle backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  // Handle close with animation
  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
      setIsClosing(false);
    }, 200);
  };
  
  if (!isOpen) return null;

  return (
    <div className={`settings-modal-overlay ${isClosing ? 'fade-out' : ''}`} onClick={handleBackdropClick}>
      <div className={`how-to-play-modal ${isClosing ? 'fade-out' : ''}`}>
        {/* Modal Header */}
        <div className="modal-header">
          <h2 className="modal-title">{t("game:howToPlay.title")}</h2>
          <button
            className="close-button"
            onClick={handleClose}
            aria-label={t("navigation.close")}
          >
            <X size={24} />
          </button>
        </div>

        <div className="modal-content">
          <div className="rule-section">
            <div style={{ display: "flex", gap: 4 }}>
              <h3>{t('game:howToPlay.gameObjective')}</h3>
            </div>
            <ul>
              <li>{t('game:howToPlay.rules.playWithFriends')}</li>
              <li>{t('game:howToPlay.rules.controlWorm')}</li>
              <li>{t('game:howToPlay.rules.useControls')}</li>
              <li>{t('game:howToPlay.rules.avoidHitting')}</li>
              <li>{t('game:howToPlay.rules.becomeLongest')}</li>
            </ul>
          </div>
          <div className="rule-section">
            <div style={{ display: "flex", gap: 4 }}>
       
              <h3>{t('game:howToPlay.scoringSystem')}</h3>
            </div>
            <ul>
              <li>{t('game:howToPlay.rules.eatFood')}</li>
              <li>{t('game:howToPlay.rules.foodPoints')}</li>
              <li>{t('game:howToPlay.rules.largerWorms')}</li>
              <li>{t('game:howToPlay.rules.competeScore')}</li>
              <li>{t('game:howToPlay.rules.bestScoreSaved')}</li>
            </ul>
          </div>
          <div className="rule-section">
            <div style={{ display: "flex", gap: 4 }}>
              <h3>{t('game:howToPlay.deathRestart')}</h3>
            </div>
            <ul>
              <li>{t('game:howToPlay.rules.gameEnds')}</li>
              <li>{t('game:howToPlay.rules.viewScore')}</li>
              <li>{t('game:howToPlay.rules.scoreResets')}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
