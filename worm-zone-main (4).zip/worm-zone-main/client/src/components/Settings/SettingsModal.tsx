import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { X } from "lucide-react";
import { useSettingsStore } from "../../stores/settingsStore";
import { MusicMuteButton } from "../Game/MusicMuteButton";
import { LanguageSelector } from "./LanguageSelector";
import socketClient from "../../services/socketClient";
import { useGameStore } from "../../stores/gameStore";

export const SettingsModal: React.FC = () => {
  const { t } = useTranslation("common");
  const isSettingsModalOpen = useSettingsStore(
    (state) => state.isSettingsModalOpen
  );
  const closeSettingsModal = useSettingsStore(
    (state) => state.closeSettingsModal
  );
  const sound = useSettingsStore((state) => state.sound);
  const isPlaying = useGameStore((state) => state.isPlaying);
  const resetGame = useGameStore((state) => state.resetGame);
  const [isClosing, setIsClosing] = useState(false);

  // Debug: Log current sound settings when modal opens
  React.useEffect(() => {
    if (isSettingsModalOpen) {
      console.log('🎵 Settings Modal opened - Current sound settings:', {
        musicMuted: sound.musicMuted,
        effectsMuted: sound.effectsMuted,
        musicVolume: sound.music,
        effectsVolume: sound.effects
      });
    }
  }, [isSettingsModalOpen, sound]);

  // Handle backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  // Handle close with animation
  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      closeSettingsModal();
      setIsClosing(false);
    }, 200);
  };

  // Handle quit confirmation
  const handleQuitConfirm = () => {
    // Disconnect from socket room first
    socketClient.leaveRoom();
    // Then reset the game state
    resetGame();
    handleClose();
  };

  if (!isSettingsModalOpen) return null;

  return (
    <div
      className={`settings-modal-overlay ${isClosing ? "fade-out" : ""}`}
      onClick={handleBackdropClick}
    >
      <div className={`settings-modal ${isClosing ? "fade-out" : ""}`}>
        {/* Modal Header */}
        <div className="modal-header">
          <h2 className="modal-title">{t("settings.title")}</h2>
          <button
            className="close-button"
            onClick={handleClose}
            aria-label={t("navigation.close")}
          >
            <X size={24} />
          </button>
        </div>

        {/* Modal Content */}
        <div className="modal-content">
          <div className="settings-section">
            {/* Language Settings */}
            <LanguageSelector />

            {/* Sound Settings */}
            <div className="setting-item">
              <label>{t("settings.sound")}</label>
              <MusicMuteButton isAbsolute={false} isMuteAll />
            </div>
            {/* <div className="setting-item">
              <label>{t("settings.effects")}</label>
              <EffectsMuteButton isAbsolute={false} />
            </div> */}

            {/* Graphics Settings */}
            {/* <QualitySelector /> */}
            {isPlaying && (
              <button onClick={handleQuitConfirm} className="to-quit-btn">
                {t("game:quit.confirm")}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
