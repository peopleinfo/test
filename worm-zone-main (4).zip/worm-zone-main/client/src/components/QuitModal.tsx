import { X } from "lucide-react";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";

interface QuitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const QuitModal: React.FC<QuitModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
}) => {
  const { t } = useTranslation("common");
  const [isClosing, setIsClosing] = useState(false);

  // Handle backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  // Handle close with animation
  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
      setIsClosing(false);
    }, 200);
  };

  // Handle confirm with animation
  const handleConfirm = () => {
    setIsClosing(true);
    setTimeout(() => {
      onConfirm();
      setIsClosing(false);
    }, 200);
  };

  if (!isOpen) return null;

  return (
    <div className={`settings-modal-overlay ${isClosing ? 'fade-out' : ''}`} onClick={handleBackdropClick}>
      <div className={`settings-modal ${isClosing ? 'fade-out' : ''}`}>
        <div className="modal-header">
          <h2 className="modal-title">{t("game:quit.button")}</h2>
          <button className="close-button" onClick={handleClose}>
            <X size={24} />
          </button>
        </div>
        <div className="modal-content">
          <p className="quit-description">{t("game:quit.description")}</p>
          <div className="modal-footer">
            <button className="quit-button" onClick={handleConfirm}>
              {t("game:quit.confirm")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
