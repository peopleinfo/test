import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { X } from "lucide-react";
import { useSettingsStore } from "../../stores/settingsStore";
import { useAuthStore } from "../../stores/authStore";

export const TopPlayersModal: React.FC = () => {
  const { t } = useTranslation(["common", "game"]);
  const isTopPlayersModalOpen = useSettingsStore(
    (state) => state.isTopPlayersModalOpen
  );
  const closeTopPlayersModal = useSettingsStore(
    (state) => state.closeTopPlayersModal
  );
  const [isClosing, setIsClosing] = useState(false);

  const rank = useAuthStore((state) => state.rank);
  const isLoadingRank = useAuthStore((state) => state.isLoadingRank);
  const getRank = useAuthStore((state) => state.getRank);

  useEffect(() => {
    if (isTopPlayersModalOpen) {
      getRank();
    }
  }, [isTopPlayersModalOpen, getRank]);

  // Handle backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  // Handle close with animation
  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      closeTopPlayersModal();
      setIsClosing(false);
    }, 200);
  };

  if (!isTopPlayersModalOpen) return null;

  return (
    <div
      className={`settings-modal-overlay ${isClosing ? "fade-out" : ""}`}
      onClick={handleBackdropClick}
    >
      <div className={`settings-modal ${isClosing ? "fade-out" : ""}`}>
        {/* Modal Header */}
        <div className="modal-header">
          <h2 className="modal-title">
            <img
              src={"/icons/rank-leaderboard.png"}
              alt="leaderboard"
              style={{ marginRight: "8px" }}
            />
            {t("game:leaderboard.title")}
          </h2>
          <button
            className="close-button"
            onClick={handleClose}
            aria-label={t("navigation.close", "Close")}
          >
            <X size={24} />
          </button>
        </div>

        {/* Modal Content */}
        <div className="modal-content">
          <div className="top-players-content">
            {isLoadingRank ? (
              <div className="loading-container">
                <div className="loading-spinner"></div>
              </div>
            ) : (
              <div className="leaderboard-container">
                {/* Table Header */}
                <div className="leaderboard-header">
                  <div className="player-rank">{t("game:leaderboard.tableHeaders.rank")}</div>
                  <div className="player-name">{t("game:leaderboard.tableHeaders.name")}</div>
                  <div className="player-score">{t("game:leaderboard.tableHeaders.score")}</div>
                </div>

                {/* Table Body */}
                <div className="leaderboard-body">
                  {rank?.topPlayers?.map((player, index) => {
                    const isCurrentUser =
                      rank?.currentUserRank?.id === player.id;
                    return (
                      <div
                        key={player.id}
                        className={`leaderboard-item ${
                          isCurrentUser ? "current-player" : ""
                        }`}
                      >
                        <div className="player-rank">{index + 1}</div>
                        <div
                          className="player-name"
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                          }}
                        >
                          <img
                            style={{
                              width: 24,
                              height: 24,
                              borderRadius: "50%",
                            }}
                            src={player.avatarUrl}
                            alt={player.name}
                          />
                          {player.name}
                        </div>
                        <div className="player-score">
                          {player.score.toLocaleString()}
                        </div>
                      </div>
                    );
                  })}

                  {/* Current User Rank (if not in top players) */}
                  <div className="leaderboard-separator" />
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="leaderboard-item top-leaderboard-item current-player">
          <div className="player-rank">{rank?.currentUserRank?.rank}</div>
          <div
            className="player-name"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <img
              style={{
                width: 24,
                height: 24,
                borderRadius: "50%",
              }}
              src={rank?.currentUserRank?.avatarUrl}
              alt={rank?.currentUserRank?.name}
            />
            {rank?.currentUserRank?.name}
          </div>
          <div className="player-score">
            {rank?.currentUserRank?.score.toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
};
