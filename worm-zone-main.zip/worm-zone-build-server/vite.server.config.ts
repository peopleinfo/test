import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig(({ mode }) => ({
  // Build configuration for server
  build: {
    // Output directory for built server files
    outDir: 'dist/server',
    // Clear output directory before build
    emptyOutDir: true,
    // Target Node.js environment
    target: 'node18', 
    // Library mode for server build
    lib: {
      entry: resolve(__dirname, 'server/server.js'),
      name: 'SnakeZoneServer',
      fileName: 'server',
      formats: ['cjs']
    },
    // Rollup options for Node.js
    rollupOptions: {
      // External dependencies that shouldn't be bundled
      external: [
        'express',
        'socket.io',
        'http',
        'path',
        'fs',
        'os',
        'crypto',
        'events',
        'stream',
        'util',
        'url',
        'querystring',
        'zlib',
        'buffer',
        'child_process'
      ],
      output: {
        // Ensure CommonJS format for Node.js compatibility
        format: 'cjs',
        entryFileNames: 'server.js',
        // External dependencies handling
        globals: {
          'express': 'express',
          'socket.io': 'socket.io',
          'http': 'http'
        }
      }
    },
    // Minification settings
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: false, // Keep console logs for server
        drop_debugger: true,
        pure_funcs: ['console.debug']
      },
      mangle: {
        // Keep function names for better debugging
        keep_fnames: true
      },
      format: {
        // Keep comments for important server info
        comments: /^!/
      }
    },
    // Source maps for debugging
    sourcemap: true,
    // Optimize for production
    reportCompressedSize: true
  },
  // Resolve configuration
  resolve: {
    alias: {
      '@': resolve(__dirname, 'server')
    }
  },
  // Define environment variables
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'production'),
    'process.env.PORT': JSON.stringify(process.env.PORT || 9000)
  },
  // Esbuild options for faster builds
  esbuild: {
    target: 'node18',
    platform: 'node',
    format: 'cjs'
  },
  
  // ViteExpress configuration
  server: {
    middlewareMode: mode === 'development' ? false : true,
    hmr: mode === 'development' ? {
      port: 5175
    } : false
  },
  
  // Optimizations for ViteExpress
  optimizeDeps: {
    exclude: ['vite-express']
  }
}));