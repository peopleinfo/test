import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <div className={styles.rule}>
      <img src="../image/mf3soeh2-w2cuoln.png" className={styles.a19712} />
      <div className={styles.frame9}>
        <div className={styles.frame1010107505}>
          <p className={styles.howToPlay}>How to Play!</p>
          <img
            src="../image/mf3soeh0-1jfist8.svg"
            className={styles.iconHeroiconsOutline}
          />
        </div>
        <div className={styles.autoWrapper}>
          <div className={styles.frame1010107512}>
            <p className={styles.objectiveAndControl}>Objective and Control</p>
            <p className={styles.playWithFriendsInThe}>
              Play with friends in the same match
              <br />
              Control your Snake to eat food and grow longer
              <br />
              Use touch controls to move
              <br />
              Avoid hitting other worms or the walls
              <br />
              Become the longest worm to dominate the arena
            </p>
          </div>
          <div className={styles.rectangle2} />
        </div>
        <div className={styles.frame1010107513}>
          <p className={styles.objectiveAndControl}>Objective and Control</p>
          <p className={styles.playWithFriendsInThe}>
            Play with friends in the same match
            <br />
            Control your worm to eat food and grow longer
            <br />
            Use touch controls to move
            <br />
            Avoid hitting other worms or the walls
            <br />
            Become the longest worm to dominate the arena
          </p>
        </div>
      </div>
    </div>
  );
}

export default Component;
