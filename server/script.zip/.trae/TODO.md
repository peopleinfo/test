# TODO:

- [x] 1: Modify GameOverModal handleRestart to not call resetGame() immediately (priority: High)
- [x] 2: Add respawn request functionality to socket client (priority: High)
- [x] 3: Update game store to handle respawn without immediate score reset (priority: Medium)
- [x] 4: Test the score persistence until server respawn (priority: Low)
