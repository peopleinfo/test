# Snake Zone Deployment Guide

This guide covers deployment options for the Snake Zone multiplayer game server using Docker and PM2.

## Prerequisites

- Node.js 18+ installed
- Docker and Docker Compose installed (for containerized deployment)
- PM2 installed globally: `npm install -g pm2`

## Quick Start

### Development
```bash
npm run dev
```

### Production with PM2
```bash
npm install
npm run pm2:prod
```

### Production with Docker
```bash
docker-compose up -d
```

## PM2 Deployment

### Installation
```bash
# Install PM2 globally
npm install -g pm2

# Install project dependencies
npm install
```

### Available PM2 Commands

| Command | Description |
|---------|-------------|
| `npm run pm2:start` | Start the server with PM2 |
| `npm run pm2:stop` | Stop the server |
| `npm run pm2:restart` | Restart the server |
| `npm run pm2:reload` | Graceful reload (zero-downtime) |
| `npm run pm2:delete` | Delete the PM2 process |
| `npm run pm2:logs` | View server logs |
| `npm run pm2:monit` | Open PM2 monitoring dashboard |
| `npm run pm2:dev` | Start in development mode |
| `npm run pm2:prod` | Start in production mode |

### PM2 Configuration

The `ecosystem.config.js` file contains:
- Process management settings
- Environment configurations
- Logging configuration
- Memory limits and restart policies
- Deployment configurations

### PM2 Features
- **Auto-restart**: Automatically restarts on crashes
- **Memory monitoring**: Restarts if memory usage exceeds 200MB
- **Log management**: Centralized logging with rotation
- **Zero-downtime deployment**: Use `reload` for graceful updates
- **Cluster mode**: Can be configured for multiple instances

## Docker Deployment

### Single Container
```bash
# Build the image
npm run docker:build

# Run the container
npm run docker:run

# View logs
npm run docker:logs

# Stop and remove
npm run docker:stop
npm run docker:remove
```

### Docker Compose (Recommended)

#### Basic Setup
```bash
# Start all services
npm run compose:up

# View logs
npm run compose:logs

# Stop all services
npm run compose:down
```

#### Production Setup with Nginx and Redis
```bash
# Start with production profile (includes Nginx and Redis)
npm run compose:prod
```

### Docker Configuration

#### Services Included
1. **snake-zone-server**: Main game server
2. **nginx**: Reverse proxy (production profile)
3. **redis**: Session storage and caching (production profile)

#### Features
- Health checks for container monitoring
- Resource limits (256MB memory, 0.5 CPU)
- Log rotation and management
- Persistent volumes for logs and data
- Network isolation

## Environment Configuration

### Environment Variables
- `NODE_ENV`: Environment mode (development/staging/production)
- `PORT`: Server port (default: 9000)

### Environment Files
Create environment-specific files:
- `.env.development`
- `.env.staging`
- `.env.production`

## Monitoring and Health Checks

### Health Check Endpoint
```
GET /health
```

Returns server status, memory usage, uptime, and player count.

### PM2 Monitoring
```bash
# Real-time monitoring
npm run pm2:monit

# View logs
npm run pm2:logs

# Process list
pm2 list
```

### Docker Monitoring
```bash
# Container stats
docker stats snake-zone-server

# Health status
docker inspect snake-zone-server | grep Health

# Logs
npm run docker:logs
```

## Production Deployment

### Server Requirements
- **CPU**: 1 core minimum, 2 cores recommended
- **Memory**: 512MB minimum, 1GB recommended
- **Storage**: 10GB minimum
- **Network**: Stable internet connection

### Security Considerations
1. Use non-root user in containers
2. Enable firewall and limit port access
3. Use HTTPS with SSL certificates
4. Regular security updates
5. Monitor logs for suspicious activity

### Scaling

#### Horizontal Scaling
For multiple server instances, consider:
- Load balancer (Nginx, HAProxy)
- Session persistence (Redis)
- Database for game state
- Message queue for inter-server communication

#### Vertical Scaling
- Increase container resource limits
- Optimize PM2 configuration
- Monitor memory and CPU usage

## Troubleshooting

### Common Issues

1. **Port already in use**
   ```bash
   npm run kill-dev
   ```

2. **Memory issues**
   - Check PM2 memory limits
   - Monitor with `npm run pm2:monit`
   - Adjust `max_memory_restart` in ecosystem.config.js

3. **Container won't start**
   - Check Docker logs: `npm run docker:logs`
   - Verify health check endpoint
   - Check resource limits

4. **Socket.io connection issues**
   - Verify CORS configuration
   - Check firewall settings
   - Ensure WebSocket support

### Log Locations

- **PM2 logs**: `./logs/` directory
- **Docker logs**: Use `docker logs` command
- **Application logs**: Console output captured by PM2/Docker

## Backup and Recovery

### Important Files to Backup
- `ecosystem.config.js`
- `docker-compose.yml`
- `Dockerfile`
- Environment files
- Log files (optional)

### Recovery Process
1. Restore configuration files
2. Rebuild Docker images or reinstall dependencies
3. Start services
4. Verify health checks

## Performance Optimization

### PM2 Optimizations
- Use `reload` instead of `restart` for zero-downtime
- Configure appropriate memory limits
- Enable log rotation
- Use clustering for CPU-intensive operations

### Docker Optimizations
- Use multi-stage builds
- Optimize image layers
- Set appropriate resource limits
- Use health checks for automatic recovery

## Support

For deployment issues:
1. Check logs first
2. Verify configuration files
3. Test health endpoints
4. Monitor resource usage
5. Review this documentation